### Hexlet tests and linter status:
[![Actions Status](https://github.com/DenisGST/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/DenisGST/python-project-49/actions)

# source .venv/bin/activate
# deactivate

# //home/denis/python-project-49

# brain-even

# pip install --upgrade --force-reinstall git+https://github.com/hexlet-boilerplates/python-package.git

**Включить запись asciinema rec**

**ссылка на asciinema урок 5**
https://asciinema.org/a/7C3Mqu6nqaziEoawzpKJmabqs

