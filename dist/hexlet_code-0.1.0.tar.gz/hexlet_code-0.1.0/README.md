### Hexlet tests and linter status:
[![Actions Status](https://github.com/DenisGST/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/DenisGST/python-project-49/actions)

"!https://api.codeclimate.com/v1/badges/79582b1dab9df9896eab/maintainability!":https://codeclimate.com/github/DenisGST/python-project-49/maintainabilitypp